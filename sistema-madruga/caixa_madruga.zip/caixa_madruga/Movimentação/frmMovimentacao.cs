﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using caixa_madruga.Movimentação;

namespace caixa_madruga.Movimentação
{
    public partial class frmMovimentacao : Form
    {

        public Movimentacao MovimentacaoSalva { get; private set; }

        public frmMovimentacao()
        {
            InitializeComponent();
        }
        public enum TipoMovimento { Entrada = 1, Saida = 2 }

        public class Movimento
        {
            public int Id { get; set; }
            public DateTime Data { get; set; }
            public string Descricao { get; set; }
            public TipoMovimento Tipo { get; set; }
            public decimal Valor { get; set; }
            public string FormaPagamento { get; set; }
        }

        public partial class FrmMovimentacao : Form
        {
            private readonly TipoMovimento _tipo;

            public FrmMovimentacao(TipoMovimento tipo)
            {
               
            }
        }



        private void frmMovimentacao_Load(object sender, EventArgs e)
        {

        }




        private void btnSalvar_Click(object sender, EventArgs e)
        {
            MovimentacaoSalva = new Movimentacao()
            {
                Cliente = txtCliente.Text,
                Valor = numValor.Value,
                Data = dtData.Value,
                Tipo = cmbTipo.Text
            };

            this.DialogResult = DialogResult.OK;
            this.Close();
        }


        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

    }
}
