﻿using caixa_madruga.Movimentação; // importando o namespace que contém frmMovimentacao
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace caixa_madruga
{
    public partial class MenuPrincipal : Form
    {
        public MenuPrincipal()
        {
            InitializeComponent();
        }

        private void MenuMovimentações_Click(object sender, EventArgs e)
        {
            // Corrigido: nome da classe correto 'frmMovimentacao' (antes havia 'frnMovimentacao')
            var mov = new frmMovimentacao();
            mov.ShowDialog();

        }

        private void MenuSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Menufuncionários_Click(object sender, EventArgs e)
        {

        }

        private void MenuPrincipal_Load(object sender, EventArgs e)
        {
            CarregarMovimentacoes();
        }

        private void CarregarMovimentacoes()
        {
            if (!File.Exists(caminhoDados))
                return;

            string[] linhas = File.ReadAllLines(caminhoDados);

            foreach (string linha in linhas)
            {
                string[] dados = linha.Split(';');

                Movimentacao m = new Movimentacao();
                m.Data = DateTime.Parse(dados[0]);
                m.Cliente = dados[1];
                m.Tipo = dados[2];
                m.Valor = decimal.Parse(dados[3]);

                movimentacoes.Add(m);
            }

            
        }

        private void menuNovaMovimentacao_Click(object sender, EventArgs e)
        {
            frmMovimentacao frm = new frmMovimentacao();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                movimentacoes.Add(frm.MovimentacaoSalva);
                SalvarMovimentacoes();
               
            }
        }


        private void SalvarMovimentacoes()
        {
            using (StreamWriter sw = new StreamWriter(caminhoDados))
            {
                foreach (var m in movimentacoes)
                {
                    sw.WriteLine($"{m.Data:yyyy-MM-dd};{m.Cliente};{m.Tipo};{m.Valor}");
                }
            }
        }


        private List<Movimentacao> movimentacoes = new List<Movimentacao>();
        private string caminhoDados = "movimentacoes.txt";





        private void MenuRelatórios_Click(object sender, EventArgs e)
        {
           
            
        }

        


        private void gerarRelatóriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (movimentacoes.Count == 0)
            {
                MessageBox.Show("Não há movimentações para gerar relatório.");
                return;
            }

            SaveFileDialog salvar = new SaveFileDialog();
            salvar.Filter = "Arquivo de Texto (*.txt)|*.txt";
            salvar.Title = "Salvar Relatório";
            salvar.FileName = $"Relatorio_Caixa_{DateTime.Now:dd-MM-yyyy_HH-mm}.txt";

            if (salvar.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(salvar.FileName))
                {
                    sw.WriteLine("BARBEARIA MADRUGA'S BARBER");                 // ⚠️ ALTERE O NOME AQUI
                    sw.WriteLine("RELATÓRIO DE MOVIMENTAÇÕES");
                    sw.WriteLine("---------------------------------------------");
                    sw.WriteLine($"Gerado em: {DateTime.Now:dd/MM/yyyy HH:mm}\n");

                    // ========================
                    // ENTRADAS
                    // ========================
                    var entradas = movimentacoes.Where(m => m.Tipo == "Entrada").ToList();
                    sw.WriteLine("=== ENTRADAS ===");
                    if (entradas.Count == 0)
                    {
                        sw.WriteLine("Nenhuma entrada registrada.");
                    }
                    else
                    {
                        foreach (var m in entradas)
                        {
                            sw.WriteLine($"{m.Data:dd/MM/yyyy} - {m.Cliente} - R$ {m.Valor:F2}");
                        }
                    }
                    sw.WriteLine($"TOTAL DE ENTRADAS: R$ {entradas.Sum(m => m.Valor):F2}\n");

                    // ========================
                    // SAÍDAS
                    // ========================
                    var saidas = movimentacoes.Where(m => m.Tipo == "Saída").ToList();

                    sw.WriteLine("=== SAÍDAS ===");
                    if (saidas.Count == 0)
                    {
                        sw.WriteLine("Nenhuma saída registrada.");
                    }
                    else
                    {
                        foreach (var m in saidas)
                        {
                            sw.WriteLine($"{m.Data:dd/MM/yyyy} - {m.Cliente} - R$ {m.Valor:F2}");
                        }
                    }
                    sw.WriteLine($"TOTAL DE SAÍDAS: R$ {saidas.Sum(m => m.Valor):F2}\n");

                    // ========================
                    // TOTAL POR DIA
                    // ========================
                    sw.WriteLine("=== TOTAL POR DIA ===");
                    var porDia = movimentacoes
                        .GroupBy(m => m.Data.Date)
                        .OrderBy(g => g.Key);

                    foreach (var dia in porDia)
                    {
                        decimal totalDia = dia.Sum(m => m.Valor);
                        sw.WriteLine($"{dia.Key:dd/MM/yyyy} - Total: R$ {totalDia:F2}");
                    }

                    sw.WriteLine("\n---------------------------------------------");

                    // ========================
                    // TOTAL GERAL
                    // ========================
                    decimal totalGeral = movimentacoes.Sum(m => m.Valor);
                    sw.WriteLine($"TOTAL GERAL DO CAIXA: R$ {totalGeral:F2}");
                }

                MessageBox.Show("Relatório gerado com sucesso!");
               
            }
         
        }
    }
}
